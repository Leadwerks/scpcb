The aim of the game is to gain as many points as possible.


Controls
--------

Player 1 - Keyboard. A = Forward. S = Shoot. Cursor keys = Move.
Player 2 - Joypad.


Points
------

* Points go in the pot.
* Bank the pot by flying within the radius of the centre red ring.
* Get shot and the pot is emptied.
* If the pot is already empty then you die.

Orange ufo		= 200 points
Yellow ufo		= 400 points
Green ufo		= 600 points
Turquoise ufo	= 800 points
Pink ufo		= 1000 points

Pink ring		= x2
Turquoise ring	= x4
Green ring		= x6
Yellow ring		= x8
Orange ring		= x10

* Same colour ufo + same colour ring = bonus camel.

Orange camel	= shield
Yellow camel 	= rapid fire
Green camel		= chain explosions
Turquoise camel	= extra speed
Pink camel		= ufos to rings